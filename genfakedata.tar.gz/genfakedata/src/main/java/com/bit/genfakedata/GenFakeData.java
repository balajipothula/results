package com.bit.genfakedata;

import java.util.Locale;
import java.util.Random;

import com.github.javafaker.Faker;

import redis.clients.jedis.Jedis;

public class GenFakeData {

  public static void main(String[] args) {

    final String host = "127.0.0.1";
    final int port = 6379;

    final int lb = 33;
    final int ub = 99;

    final int htnolb = 9999;
    final int htnoub = 99999;

    final int recPerDB = 10000;

    int db = 0;

    String fname = null;
    String lname = null;

    int tel = 0;
    int hin = 0;
    int eng = 0;
    int mat = 0;
    int sci = 0;
    int soc = 0;

    Jedis redis = new Jedis(host, port);
    Faker faker = new Faker(new Locale("en-IND"));
    Random random = new Random();

    try {

      for (int no = htnoub; no > htnolb; no--) {

        fname = faker.name().firstName().replaceAll("'", "");
        lname = faker.name().lastName().replaceAll("'", "");
        tel = random.nextInt(ub - lb) + lb;
        hin = random.nextInt(ub - lb) + lb;
        eng = random.nextInt(ub - lb) + lb;
        mat = random.nextInt(ub - lb) + lb;
        sci = random.nextInt(ub - lb) + lb;
        soc = random.nextInt(ub - lb) + lb;

        db = no / recPerDB;
        redis.select(db);

        redis.hset("ht:" + no, "fname", fname);
        redis.hset("ht:" + no, "lname", lname);

        redis.hset("ht:" + no, "tel", Integer.toString(tel));
        redis.hset("ht:" + no, "hin", Integer.toString(hin));
        redis.hset("ht:" + no, "eng", Integer.toString(eng));
        redis.hset("ht:" + no, "mat", Integer.toString(mat));
        redis.hset("ht:" + no, "sci", Integer.toString(sci));
        redis.hset("ht:" + no, "soc", Integer.toString(soc));

        System.out
            .println(String.format("%d%4d%4d%4d%4d%4d%4d\t%-20s%-20s", no, tel, hin, eng, mat, sci, soc, fname, lname));
        Thread.sleep(1);

      }

    } catch (InterruptedException interruptedException) {
      interruptedException.printStackTrace();
    } catch (Exception exception) {
      exception.printStackTrace();
    } finally {
      try {
        if (null != redis) {
          redis.close();
        }
      } catch (Exception exception) {
        exception.printStackTrace();
      }
    }

  }
}
